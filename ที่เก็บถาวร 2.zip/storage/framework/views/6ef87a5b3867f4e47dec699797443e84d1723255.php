<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-end bd-highlight mb-3">
            <div class="p-2"><a href="#">ประวัติ</a></div>
            <div class="p-2"><a href="#">ตระกร้า ( 0 )</a></div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped">
                    <thead>
                            <tr>
                                <th>เลขที่รายการ</th>
                                <th>สถานะ</th>
                                <th>วันที่สิ้นสุดการยืม</th>
                                <th>รายละเอียด</th>
                            </tr>
                    </thead>
                    <tbody>
                    <?php if(!$orders->isEmpty()): ?>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->id); ?></td>
                                <td>
                                    <?php if(!$order->status == 0): ?>
                                        รอดำเนินการ
                                    <?php elseif($order->status == 1): ?>
                                        อนุมัติแล้ว
                                    <?php elseif($order->status == 2): ?>
                                        รับอุปกรณ์แล้ว
                                    <?php elseif($order->status == 3): ?>
                                        คืนอุปกรณ์แล้ว
                                    <?php else: ?>
                                        ไม่ได้รับการอนุมัติ
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e(\App\Utils\Helper::dateToThai($order->end_date)); ?>

                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-primary"
                                        @click="showDetail(<?php echo e($order->id); ?>)">รายละเอียด</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>




















    <div class="modal fade" id="modal_detail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div id="modal_content" class="modal-dialog modal-lg" role="document">

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        var app = new Vue({
            el: '#app',
            data: {},
            methods: {
                showDetail(id) {
                    axios.get('/history/'+id)
                        .then(function(response){
                            if(response.data.status==200){
                                $('#modal_content').html(response.data.html);
                                // console.log(response.data.html);
                              $('#modal_detail').modal('show');
                            }else{
                                swal("ผิดพลาด",response.data.message,"error");
                            }
                        })
                        .catch(function() {
                            console.log('errors');
                        });
                }
            }
        })
    </script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/borrow/resources/views/user/history.blade.php ENDPATH**/ ?>