<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">รายการเลขที่ : <?php echo e($order->id); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>รูป</th>
                <th>รหัสอุปกรณ์</th>
                <th>รายละเอียด</th>
            </tr>
            </thead>
            <tbody>
            <?php if(!empty($order->details)): ?>
                <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="100">
                            <img class="img-fluid" src="<?php echo e(url('/uploads/'.$detail->item->image)); ?>">
                        </td>
                        <td class="align-middle"><?php echo e($detail->item->id); ?></td>
                        <td class="align-middle"><?php echo e($detail->item->title); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/borrow/resources/views/user/history-detail.blade.php ENDPATH**/ ?>