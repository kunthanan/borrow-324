<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-end bd-highlight mb-3">
            <div class="p-2"><a href="/history">ประวัติ</a></div>
            <div class="p-2"><a href="/cart">ตระกร้า ( <?php echo e($count_item_in_cart); ?> )</a></div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>รูป</th>
                            <th>รหัสอุปกรณ์</th>
                            <th>รายละเอียด</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                     <?php if(!$carts->isEmpty()): ?>
                         <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td width="150">
                                        <img class="img-fluid" src="<?php echo e(url('/uploads/'.$cart->item->image)); ?>"style="height: 200px; width: 200px; object-fit: cover;" >
                                    </td>
                                    <td class="align-middle"><?php echo e($cart->item->id); ?></td>
                                    <td class="align-middle"><?php echo e($cart->item->title); ?></td>
                                    <td class="align-middle">
                                        <button type="button" class="btn btn-danger"
                                        @click="removeInCart(<?php echo e($cart->item->id); ?>)">ลบ</button>
                                    </td>
                                </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-between">
                    <button type="button" class="btn btn-outline-primary"
                    @click="clearCart()"
                    >เคลียตระกร้า</button>
                    <button type="button" class="btn btn-success"
                            @click="createOrder">ยืนยันรายการ</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var app = new Vue({
            el: '#app',
            data: {},
            methods:{
                removeInCart(id){
                    axios.post('/cart/'+id+'/delete')
                        .then(function(response){
                            console.log(response);
                            if(response.data.status==200){
                                swal({
                                    icon:"success"
                                    ,text:response.data.message
                                    ,button:false
                                });
                                setTimeout(function (){
                                    window.location.reload();
                                },2000);
                            }else{
                                swal("ผิดพลาด",response.data.message,"error");
                            }
                        })
                        .catch(function(){
                            console.log('error');
                        });
                },
                clearCart(){
                    axios.post('/cart/delete')
                        .then(function(response){
                            console.log(response);
                            if(response.data.status==200){
                                swal({
                                    icon:"success"
                                    ,text:response.data.message
                                    ,button:false
                                });
                                setTimeout(function (){
                                    window.location.reload();
                                },2000);
                            }else{
                                swal("ผิดพลาด",response.data.message,"error");
                            }
                        })
                        .catch(function(){
                            console.log('error');
                        });
                },
                createOrder(){
                    axios.post('/cart')
                        .then(function(response){
                            console.log(response);
                            if(response.data.status==200){
                                swal({
                                    icon:"success"
                                    ,text:response.data.message
                                    ,button:false
                                });
                                setTimeout(function (){
                                    window.location ='/history';
                                },2000);
                            }else{
                                swal("ผิดพลาด",response.data.message,"error");
                            }
                        })
                        .catch(function(){
                            console.log('error');
                        });
                }


            }
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/borrow/resources/views/user/cart.blade.php ENDPATH**/ ?>